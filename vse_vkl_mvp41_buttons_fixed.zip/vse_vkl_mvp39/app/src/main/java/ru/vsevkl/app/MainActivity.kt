package ru.vsevkl.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Window
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Button
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("vse_vkl", MODE_PRIVATE) }

    private fun apiBase(): String = prefs.getString("api_base_url", "http://10.0.2.2:3000") ?: "http://10.0.2.2:3000"

    inner class AndroidConfig {
        @JavascriptInterface fun getApiBaseUrl(): String = apiBase()
        @JavascriptInterface fun openServerSettings() { runOnUiThread { showServerDialog() } }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        web = WebView(this)
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.addJavascriptInterface(AndroidConfig(), "AndroidConfig")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun showServerDialog() {
        val input = EditText(this)
        input.setSingleLine(true)
        input.hint = "https://api.example.ru"
        input.setText(apiBase())
        val box = LinearLayout(this)
        box.setPadding(40, 0, 40, 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Адрес сервера")
            .setMessage("Укажи адрес API. Для эмулятора Android обычно используется http://10.0.2.2:3000")
            .setView(box)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                val value = input.text.toString().trim().trimEnd('/')
                if (value.isNotEmpty()) {
                    prefs.edit().putString("api_base_url", value).apply()
                    web.evaluateJavascript("localStorage.setItem('vse_vkl_api', ${org.json.JSONObject.quote(value)}); location.reload();", null)
                    Toast.makeText(this, "Адрес сервера сохранён", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
